package com.vauth.foxyvpn.ui.theme

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

val PhantomPink = Color(0xFFFF6BD6)

/**
 * Soft, slowly drifting colour blobs behind everything. The translucent "glass" panels
 * drawn on top of it pick these colours up, which is what sells the liquid-glass look.
 */
@Composable
fun GlassBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val dark = scheme.background.luminance() < 0.5f
    val transition = rememberInfiniteTransition(label = "glass-bg")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(22_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "glass-phase",
    )
    val blobAlpha = if (dark) 0.34f else 0.26f
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(scheme.background, scheme.surfaceContainerLowest)))
            .drawBehind {
                val radius = size.maxDimension * 0.55f
                fun blob(color: Color, cx: Float, cy: Float) {
                    val center = Offset(cx, cy)
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(color.copy(alpha = blobAlpha), Color.Transparent),
                            center = center,
                            radius = radius,
                        ),
                        radius = radius,
                        center = center,
                    )
                }
                blob(PhantomViolet, size.width * (0.15f + 0.35f * phase), size.height * (0.12f + 0.10f * phase))
                blob(PhantomCyan, size.width * (0.95f - 0.30f * phase), size.height * (0.55f + 0.12f * phase))
                blob(PhantomPink, size.width * (0.25f + 0.25f * phase), size.height * (0.98f - 0.12f * phase))
            },
        content = content,
    )
}

/**
 * A frosted, translucent panel: soft fill, a bright specular sheen on the upper half and a
 * thin gradient rim light, like a piece of glass catching the light.
 */
@Composable
fun Modifier.glassSurface(
    shape: Shape = RoundedCornerShape(24.dp),
    tint: Color = Color.Unspecified,
    borderWidth: Dp = 1.dp,
): Modifier {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val fillTop = if (dark) Color.White.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.78f)
    val fillBottom = if (dark) Color.White.copy(alpha = 0.05f) else Color.White.copy(alpha = 0.42f)
    val sheen = if (dark) Color.White.copy(alpha = 0.10f) else Color.White.copy(alpha = 0.45f)
    val rimLight = if (dark) Color.White.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.95f)
    val rimShade = if (dark) Color.White.copy(alpha = 0.08f) else PhantomViolet.copy(alpha = 0.22f)
    val base = if (tint == Color.Unspecified) Color.Transparent else tint.copy(alpha = if (dark) 0.14f else 0.12f)
    return this
        .clip(shape)
        .background(base)
        .background(Brush.linearGradient(listOf(fillTop, fillBottom)))
        .drawBehind {
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(sheen, Color.Transparent),
                    startY = 0f,
                    endY = size.height * 0.55f,
                ),
            )
        }
        .border(
            borderWidth,
            Brush.linearGradient(listOf(rimLight, rimShade, rimLight.copy(alpha = rimLight.alpha * 0.5f))),
            shape,
        )
}

/**
 * Wraps a whole screen (Scaffold based ones such as Settings) in the glass background and makes
 * the theme's page/surface colours transparent so list rows and app bars show it through.
 * Dialogs and sheets keep their normal opaque containers.
 */
@Composable
fun GlassScreen(content: @Composable () -> Unit) {
    GlassBackground {
        MaterialExpressiveTheme(
            colorScheme = MaterialTheme.colorScheme.copy(
                background = Color.Transparent,
                surface = Color.Transparent,
            ),
            typography = MaterialTheme.typography,
            motionScheme = MotionScheme.expressive(),
        ) {
            content()
        }
    }
}
