package com.vauth.foxyvpn.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vauth.foxyvpn.ui.theme.PhantomCyan
import com.vauth.foxyvpn.ui.theme.PhantomPink
import com.vauth.foxyvpn.ui.theme.PhantomViolet
import com.vauth.foxyvpn.ui.theme.glassSurface

/**
 * Shows who made the app: a glass pill with a gradient monogram, the Persian name in a slowly
 * shimmering gradient and the Latin spelling underneath.
 */
@Composable
fun CreatorBadge(modifier: Modifier = Modifier) {
    val scheme = MaterialTheme.colorScheme
    val transition = rememberInfiniteTransition(label = "creator-shimmer")
    val shift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3600, easing = LinearEasing), RepeatMode.Restart),
        label = "creator-shift",
    )
    val period = 600f
    val shimmer = Brush.linearGradient(
        colors = listOf(PhantomViolet, PhantomCyan, PhantomPink, PhantomViolet),
        start = Offset(shift * period, 0f),
        end = Offset(shift * period + period, 0f),
        tileMode = TileMode.Repeated,
    )

    Row(
        modifier = modifier
            .glassSurface(RoundedCornerShape(28.dp), tint = PhantomViolet)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(PhantomViolet, PhantomCyan))),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                "AM",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 0.5.sp,
                ),
                color = Color.White,
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "سازنده",
                style = MaterialTheme.typography.labelMedium,
                color = scheme.onSurfaceVariant,
            )
            Text(
                "علیرضا مقیاسی",
                style = MaterialTheme.typography.titleLarge.copy(
                    brush = shimmer,
                    fontWeight = FontWeight.ExtraBold,
                ),
            )
            Text(
                "ALIREZA MOGHYASI",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 2.sp,
                ),
                color = scheme.onSurfaceVariant,
            )
        }
    }
}
