package com.vauth.foxyvpn.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vauth.foxyvpn.FoxyVpnApp
import com.vauth.foxyvpn.data.model.ConnectionState
import com.vauth.foxyvpn.data.model.emojiFlag
import com.vauth.foxyvpn.ui.theme.glassSurface
import com.vauth.foxyvpn.vpn.FastestServer
import com.vauth.foxyvpn.vpn.FoxyVpnService
import com.vauth.foxyvpn.vpn.SpeedTest
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Extra tools shown under the stats on the home screen: a tunnel speed test, a "find the quickest
 * location" search and a one-tap copy of the current exit IP.
 */
@Composable
fun ToolsCard(
    app: FoxyVpnApp,
    state: ConnectionState,
    modifier: Modifier = Modifier,
) {
    val scheme = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val haptics = LocalHapticFeedback.current
    val clipboard = LocalClipboardManager.current
    val exitIp by FoxyVpnService.vpnEdgeIp.collectAsState()

    var speedBusy by remember { mutableStateOf(false) }
    var speedText by remember { mutableStateOf<String?>(null) }
    var fastBusy by remember { mutableStateOf(false) }
    var fastText by remember { mutableStateOf<String?>(null) }
    var copyText by remember { mutableStateOf<String?>(null) }

    val connected = state == ConnectionState.CONNECTED
    val disconnected = state == ConnectionState.DISCONNECTED
    val ip = exitIp?.ip?.takeIf { it.isNotBlank() }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .glassSurface(RoundedCornerShape(24.dp))
            .padding(18.dp),
    ) {
        Text("Tools", style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))

        ToolRow(
            icon = Icons.Filled.Speed,
            title = "Speed test",
            subtitle = speedText ?: if (connected) {
                "Measure download speed through the tunnel"
            } else {
                "Connect first to test the tunnel"
            },
            action = "Run",
            busy = speedBusy,
            enabled = connected && !speedBusy,
        ) {
            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
            speedBusy = true
            speedText = "Testing\u2026"
            scope.launch {
                val result = SpeedTest.run(app.settingsStore.socksPort)
                speedText = result.fold(
                    onSuccess = {
                        String.format(Locale.US, "%.1f Mbps down \u2022 %d ms", it.downloadMbps, it.latencyMs)
                    },
                    onFailure = { "Test failed: ${it.message ?: "unknown error"}" },
                )
                speedBusy = false
            }
        }

        Spacer(Modifier.height(14.dp))

        ToolRow(
            icon = Icons.Filled.Bolt,
            title = "Fastest server",
            subtitle = fastText ?: if (disconnected) {
                "Ping every location and pick the quickest"
            } else {
                "Disconnect to search for a faster location"
            },
            action = "Find",
            busy = fastBusy,
            enabled = disconnected && !fastBusy,
        ) {
            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
            fastBusy = true
            fastText = "Pinging locations\u2026"
            scope.launch {
                val pick = runCatching { FastestServer.find(app.serverListClient) }.getOrNull()
                if (pick == null) {
                    fastText = "No server answered. Check your connection and try again."
                } else {
                    app.proxyStateStore.save(pick.candidate)
                    val name = pick.candidate.countryName.ifBlank { pick.candidate.countryCode }
                    fastText = "${pick.candidate.emojiFlag} $name \u2022 ${pick.latencyMs} ms \u2022 selected"
                }
                fastBusy = false
            }
        }

        Spacer(Modifier.height(14.dp))

        ToolRow(
            icon = Icons.Filled.ContentCopy,
            title = "Copy exit IP",
            subtitle = copyText ?: ip ?: "Available once connected",
            action = "Copy",
            busy = false,
            enabled = connected && ip != null,
        ) {
            val value = ip ?: return@ToolRow
            clipboard.setText(AnnotatedString(value))
            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
            copyText = "Copied $value"
        }
    }
}

@Composable
private fun ToolRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    action: String,
    busy: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(scheme.primary.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = scheme.primary, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold))
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(10.dp))
        FilledTonalButton(onClick = onClick, enabled = enabled) {
            if (busy) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
            } else {
                Text(action)
            }
        }
    }
}
